package com.example.util

import java.text.DecimalFormat
import java.util.Locale

enum class AppLanguage {
  MIZO,
  ENGLISH
}

object AppStrings {
  fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, 4)
    val df = DecimalFormat("#,##0.#")
    return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
  }

  fun getTitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Junk Cleaner Pro"
    AppLanguage.ENGLISH -> "Junk Cleaner Pro"
  }

  fun getSubtitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Storage & System Tihfaina Chak Tak"
    AppLanguage.ENGLISH -> "Fast Storage & Performance Cleaner"
  }

  fun getDeveloperCredit(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Developer: Laltlanlawma"
    AppLanguage.ENGLISH -> "Developer: Laltlanlawma"
  }

  fun getCleanNowBtn(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Bawlhhlawh Thian Fai Rawh"
    AppLanguage.ENGLISH -> "Clean All Junk Now"
  }

  fun getScanBtn(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Bawlhhlawh Enchhin Rawh"
    AppLanguage.ENGLISH -> "Scan Junk Files"
  }

  fun getScanningText(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Storage leh App Cache te kan lo enfiah mek e..."
    AppLanguage.ENGLISH -> "Scanning storage & application cache..."
  }

  fun getCleaningText(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Junk files leh cache te kan tifai mek..."
    AppLanguage.ENGLISH -> "Cleaning cache & temporary junk files..."
  }

  fun getCleanSuccessTitle(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Tihfai a ni ta e!"
    AppLanguage.ENGLISH -> "Cleanup Completed!"
  }

  fun getStorageUsage(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Storage Hman Zat"
    AppLanguage.ENGLISH -> "Storage Usage"
  }

  fun getRamUsage(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "RAM Hman Zat"
    AppLanguage.ENGLISH -> "RAM Memory"
  }

  fun getBoostRam(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "RAM Tichak Rawh"
    AppLanguage.ENGLISH -> "Boost RAM"
  }

  fun getRamBoostedMessage(lang: AppLanguage, mb: Long): String = when (lang) {
    AppLanguage.MIZO -> "RAM ${mb}MB release a ni ta a, phone a chak sawt e!"
    AppLanguage.ENGLISH -> "Released ${mb}MB RAM, performance boosted!"
  }

  fun getTargetAppsTab(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "App Lente Tihfaina"
    AppLanguage.ENGLISH -> "App Cleaner"
  }

  fun getJunkCategoriesTab(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "Junk List"
    AppLanguage.ENGLISH -> "Junk Categories"
  }

  fun getSystemBoostTab(lang: AppLanguage): String = when (lang) {
    AppLanguage.MIZO -> "System Status"
    AppLanguage.ENGLISH -> "System Status"
  }

  fun getClearCacheInstruction(lang: AppLanguage, appName: String): String = when (lang) {
    AppLanguage.MIZO -> "$appName cache paih turin 'Settings > Storage > Clear Cache' hmet rawh."
    AppLanguage.ENGLISH -> "To clear $appName cache, tap below to open Storage Settings & Clear Cache."
  }
}
