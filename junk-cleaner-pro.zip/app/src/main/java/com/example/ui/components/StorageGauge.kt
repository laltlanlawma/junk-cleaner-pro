package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DevicePerformanceStats
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.AppStrings

@Composable
fun StorageGauge(
  stats: DevicePerformanceStats,
  isScanning: Boolean,
  language: AppLanguage,
  modifier: Modifier = Modifier
) {
  val storagePercentage = if (stats.storageTotalBytes > 0) {
    (stats.storageUsedBytes.toFloat() / stats.storageTotalBytes.toFloat()).coerceIn(0f, 1f)
  } else 0.5f

  val ramPercentage = if (stats.ramTotalBytes > 0) {
    (stats.ramUsedBytes.toFloat() / stats.ramTotalBytes.toFloat()).coerceIn(0f, 1f)
  } else 0.6f

  // Smooth animated percentage transition
  val animatedStorageProgress by animateFloatAsState(
    targetValue = storagePercentage,
    animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
    label = "storageProgress"
  )

  // Infinite pulsing glow when scanning
  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val pulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseAlpha"
  )

  val rotationAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(2000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(200.dp)
      ) {
        // Outer arc for Storage and Inner arc for RAM
        Canvas(modifier = Modifier.size(190.dp)) {
          val strokeWidthOuter = 16.dp.toPx()
          val strokeWidthInner = 10.dp.toPx()

          // Background track for Storage
          drawArc(
            color = Color(0xFF1E293B),
            startAngle = 135f,
            sweepAngle = 270f,
            useCenter = false,
            style = Stroke(width = strokeWidthOuter, cap = StrokeCap.Round)
          )

          // Storage used progress arc
          val storageSweep = 270f * animatedStorageProgress
          drawArc(
            brush = Brush.sweepGradient(
              colors = listOf(
                ElectricCyan,
                EmeraldClean,
                ElectricCyanDark,
                ElectricCyan
              )
            ),
            startAngle = 135f,
            sweepAngle = storageSweep,
            useCenter = false,
            style = Stroke(width = strokeWidthOuter, cap = StrokeCap.Round)
          )

          // Inner track for RAM
          drawArc(
            color = Color(0xFF1E293B).copy(alpha = 0.6f),
            startAngle = 135f,
            sweepAngle = 270f,
            useCenter = false,
            style = Stroke(width = strokeWidthInner, cap = StrokeCap.Round),
            size = size.copy(width = size.width - 44.dp.toPx(), height = size.height - 44.dp.toPx()),
            topLeft = androidx.compose.ui.geometry.Offset(22.dp.toPx(), 22.dp.toPx())
          )

          // RAM used progress arc
          val ramSweep = 270f * ramPercentage
          drawArc(
            brush = Brush.linearGradient(listOf(AmberWarning, CoralDanger)),
            startAngle = 135f,
            sweepAngle = ramSweep,
            useCenter = false,
            style = Stroke(width = strokeWidthInner, cap = StrokeCap.Round),
            size = size.copy(width = size.width - 44.dp.toPx(), height = size.height - 44.dp.toPx()),
            topLeft = androidx.compose.ui.geometry.Offset(22.dp.toPx(), 22.dp.toPx())
          )
        }

        // Center Readout
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          if (isScanning) {
            Icon(
              imageVector = Icons.Default.CleaningServices,
              contentDescription = null,
              tint = ElectricCyan.copy(alpha = pulseAlpha),
              modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (language == AppLanguage.MIZO) "Enfiah mek..." else "Scanning...",
              style = MaterialTheme.typography.labelLarge,
              color = ElectricCyan,
              fontWeight = FontWeight.Bold
            )
          } else {
            Text(
              text = "${(storagePercentage * 100).toInt()}%",
              style = MaterialTheme.typography.headlineLarge,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onSurface,
              fontSize = 36.sp
            )
            Text(
              text = if (language == AppLanguage.MIZO) "STORAGE HMAN" else "STORAGE USED",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
              fontWeight = FontWeight.SemiBold,
              letterSpacing = 1.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Dual Info Cards (Storage Free & RAM Free)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Storage Stat Pill
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(ElectricCyan.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Storage,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == AppLanguage.MIZO) "Awl zat" else "Free Storage",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
              )
              Text(
                text = AppStrings.formatBytes(stats.storageFreeBytes),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = ElectricCyan
              )
            }
          }
        }

        // RAM Stat Pill
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(AmberWarning.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Memory,
                contentDescription = null,
                tint = AmberWarning,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (language == AppLanguage.MIZO) "RAM awl" else "Free RAM",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
              )
              Text(
                text = AppStrings.formatBytes(stats.ramFreeBytes),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = AmberWarning
              )
            }
          }
        }
      }
    }
  }
}
