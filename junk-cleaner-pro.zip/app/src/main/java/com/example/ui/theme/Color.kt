package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Electric Cyan / Tech Blue
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF00B0FF)
val DeepNavy = Color(0xFF0A0F1D)
val SurfaceNavy = Color(0xFF131B2E)
val CardNavy = Color(0xFF1A243B)
val LightCardNavy = Color(0xFF24314F)

// Accent Emerald / Success Green
val EmeraldClean = Color(0xFF00E676)
val EmeraldCleanDark = Color(0xFF00B248)

// Warning / Danger Accent
val AmberWarning = Color(0xFFFFAB00)
val CoralDanger = Color(0xFFFF5252)

// App Brand Colors
val WhatsAppGreen = Color(0xFF25D366)
val FacebookBlue = Color(0xFF1877F2)
val MessengerPurple = Color(0xFF0099FF)
val YouTubeRed = Color(0xFFFF0000)
val InstagramPink = Color(0xFFE1306C)
val ChromeYellow = Color(0xFFFBBC05)
val TwitterBlue = Color(0xFF1DA1F2)
val GoogleBlue = Color(0xFF4285F4)

// Light Theme Palette
val LightPrimary = Color(0xFF006874)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFF97F0FF)
val LightOnPrimaryContainer = Color(0xFF001F24)
val LightBackground = Color(0xFFF6F8FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE7ECF3)
val LightOnSurface = Color(0xFF191C1E)

// Dark Theme Palette
val DarkPrimary = Color(0xFF00E5FF)
val DarkOnPrimary = Color(0xFF00363D)
val DarkPrimaryContainer = Color(0xFF004F58)
val DarkOnPrimaryContainer = Color(0xFF97F0FF)
val DarkBackground = Color(0xFF0B111E)
val DarkSurface = Color(0xFF111A2E)
val DarkSurfaceVariant = Color(0xFF1B263E)
val DarkOnSurface = Color(0xFFE2E8F0)

