package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JunkCategoryGroup
import com.example.model.JunkCategoryType
import com.example.model.JunkItem
import com.example.ui.theme.ElectricCyan
import com.example.util.AppLanguage
import com.example.util.AppStrings

@Composable
fun JunkCategoryCard(
  group: JunkCategoryGroup,
  language: AppLanguage,
  onToggleCategory: (JunkCategoryType) -> Unit,
  onToggleExpand: (JunkCategoryType) -> Unit,
  onToggleItem: (JunkCategoryType, String) -> Unit,
  modifier: Modifier = Modifier
) {
  val icon: ImageVector = when (group.category) {
    JunkCategoryType.APP_CACHE -> Icons.Default.FolderZip
    JunkCategoryType.WHATSAPP_JUNK -> Icons.Default.ChatBubble
    JunkCategoryType.SOCIAL_MEDIA_CACHE -> Icons.Default.Share
    JunkCategoryType.TEMP_FILES -> Icons.Default.Description
    JunkCategoryType.OBSOLETE_APKS -> Icons.Default.Android
    JunkCategoryType.EMPTY_FOLDERS -> Icons.Default.FolderOpen
    JunkCategoryType.BIG_FILES -> Icons.Default.SdCard
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp)),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onToggleExpand(group.category) },
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Selection Checkbox
        Checkbox(
          checked = group.isSelected,
          onCheckedChange = { onToggleCategory(group.category) },
          colors = CheckboxDefaults.colors(checkedColor = group.accentColor)
        )

        // Category Icon
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(group.accentColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = group.accentColor,
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = if (language == AppLanguage.MIZO) group.nameMizo else group.nameEn,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = if (language == AppLanguage.MIZO) group.descriptionMizo else group.descriptionEn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            maxLines = 1
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = if (group.category == JunkCategoryType.EMPTY_FOLDERS) {
              "${group.items.size} folders"
            } else {
              AppStrings.formatBytes(group.totalSizeBytes)
            },
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = group.accentColor
          )
          Icon(
            imageVector = if (group.isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            modifier = Modifier.size(20.dp)
          )
        }
      }

      // Expandable Items List
      AnimatedVisibility(visible = group.isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, start = 8.dp, end = 8.dp)
        ) {
          Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
          Spacer(modifier = Modifier.height(8.dp))

          if (group.items.isEmpty()) {
            Text(
              text = if (language == AppLanguage.MIZO) "Bawlhhlawh a awm rih lo / Tihfai tawh a ni." else "No junk files found or already cleaned.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
              modifier = Modifier.padding(vertical = 6.dp)
            )
          } else {
            group.items.forEach { item ->
              JunkItemRow(
                item = item,
                accentColor = group.accentColor,
                onToggle = { onToggleItem(group.category, item.id) }
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun JunkItemRow(
  item: JunkItem,
  accentColor: androidx.compose.ui.graphics.Color,
  onToggle: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
      .clip(RoundedCornerShape(8.dp))
      .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
      .clickable { onToggle() }
      .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Checkbox(
      checked = item.isSelected,
      onCheckedChange = { onToggle() },
      colors = CheckboxDefaults.colors(checkedColor = accentColor),
      modifier = Modifier.size(28.dp)
    )
    Spacer(modifier = Modifier.width(8.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = item.title,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1
      )
      Text(
        text = item.description.ifBlank { item.path },
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
        maxLines = 1,
        fontSize = 10.sp
      )
    }
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = if (item.sizeBytes > 0) AppStrings.formatBytes(item.sizeBytes) else "${item.fileCount} items",
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
    )
  }
}
