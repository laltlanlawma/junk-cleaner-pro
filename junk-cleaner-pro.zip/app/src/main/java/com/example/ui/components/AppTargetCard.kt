package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TargetAppInfo
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.AppStrings

@Composable
fun AppTargetCard(
  appInfo: TargetAppInfo,
  language: AppLanguage,
  onOpenSettings: (packageName: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var isExpanded by remember { mutableStateOf(false) }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(18.dp))
      .clickable { isExpanded = !isExpanded },
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // App Icon Avatar with Brand Accent
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(appInfo.brandColor.copy(alpha = 0.18f)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = appInfo.appName.take(1).uppercase(),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = appInfo.brandColor
          )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = appInfo.appName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            if (appInfo.isInstalled) {
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(EmeraldClean.copy(alpha = 0.2f))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = if (language == AppLanguage.MIZO) "Awm mek" else "Installed",
                  style = MaterialTheme.typography.labelSmall,
                  color = EmeraldClean,
                  fontSize = 10.sp
                )
              }
            }
          }

          Text(
            text = if (appInfo.estimatedCacheBytes > 0) {
              "~${AppStrings.formatBytes(appInfo.estimatedCacheBytes)} cache & temp"
            } else {
              if (language == AppLanguage.MIZO) "Cache tihfai theih" else "Cleanable app cache"
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
          )
        }

        // Quick Deep-Clean Action Button
        Button(
          onClick = { onOpenSettings(appInfo.packageName) },
          colors = ButtonDefaults.buttonColors(
            containerColor = appInfo.brandColor.copy(alpha = 0.9f)
          ),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.height(36.dp)
        ) {
          Icon(
            imageVector = Icons.Default.CleaningServices,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = Color.White
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (language == AppLanguage.MIZO) "Tifai" else "Clean",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }

      // Expandable Specific Junk Breakdown & Cleaning Guide
      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
        ) {
          Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = if (language == AppLanguage.MIZO) "Bawlhhlawh awm theite:" else "Detected Junk Types:",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
          )

          Spacer(modifier = Modifier.height(6.dp))

          // Junk tags flow row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            appInfo.specificJunkTypes.take(3).forEach { tag ->
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(MaterialTheme.colorScheme.surface)
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = tag,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                  fontSize = 11.sp
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Instruction Callout
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(MaterialTheme.colorScheme.surface)
              .padding(10.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (language == AppLanguage.MIZO) appInfo.guideMizo else appInfo.guideEn,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                lineHeight = 16.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedButton(
            onClick = { onOpenSettings(appInfo.packageName) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(
              contentColor = ElectricCyan
            )
          ) {
            Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (language == AppLanguage.MIZO) {
                "${appInfo.appName} Storage Settings hawng rawh"
              } else {
                "Open ${appInfo.appName} Storage Settings"
              },
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}
