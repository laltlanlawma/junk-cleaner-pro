package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.CleanerState
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.AppStrings
import com.example.viewmodel.CleanerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleanerDashboardScreen(
  viewModel: CleanerViewModel,
  modifier: Modifier = Modifier
) {
  val language by viewModel.appLanguage.collectAsStateWithLifecycle()
  val stats by viewModel.deviceStats.collectAsStateWithLifecycle()
  val targetApps by viewModel.targetApps.collectAsStateWithLifecycle()
  val junkGroups by viewModel.junkGroups.collectAsStateWithLifecycle()
  val cleanerState by viewModel.cleanerState.collectAsStateWithLifecycle()
  val scanProgress by viewModel.scanProgress.collectAsStateWithLifecycle()
  val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
  val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
  val showDevDialog by viewModel.showDevDialog.collectAsStateWithLifecycle()
  val snackBarMessage by viewModel.snackBarMessage.collectAsStateWithLifecycle()

  val isScanning = cleanerState == CleanerState.SCANNING
  val isCleaning = cleanerState == CleanerState.CLEANING

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(snackBarMessage) {
    snackBarMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  if (showDevDialog) {
    DeveloperInfoDialog(
      language = language,
      onDismiss = { viewModel.setShowDevDialog(false) },
      onOpenStorageSettings = { viewModel.openSystemStorageSettings() }
    )
  }

  Scaffold(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = AppStrings.getTitle(language),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Black,
              color = MaterialTheme.colorScheme.onBackground
            )
            Text(
              text = "Dev: Laltlanlawma",
              style = MaterialTheme.typography.labelSmall,
              color = ElectricCyan,
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp
            )
          }
        },
        actions = {
          // Language Switcher (Mizo / English)
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.padding(end = 6.dp)
          ) {
            Row(
              modifier = Modifier.padding(4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              LanguageChip(
                text = "Mizo",
                isSelected = language == AppLanguage.MIZO,
                onClick = { viewModel.setLanguage(AppLanguage.MIZO) }
              )
              LanguageChip(
                text = "EN",
                isSelected = language == AppLanguage.ENGLISH,
                onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) }
              )
            }
          }

          // Dev Info / About button
          IconButton(
            onClick = { viewModel.setShowDevDialog(true) },
            modifier = Modifier.testTag("dev_info_button")
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = "About App & Developer",
              tint = MaterialTheme.colorScheme.onBackground
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background
        )
      )
    },
    bottomBar = {
      // Bottom Quick Action Master Bar
      Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.navigationBars)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
          // Master Clean / Scan CTA
          Button(
            onClick = {
              if (cleanerState == CleanerState.SCAN_COMPLETED) {
                viewModel.cleanSelectedJunk()
              } else {
                viewModel.startScan(autoClean = true)
              }
            },
            enabled = !isScanning && !isCleaning,
            modifier = Modifier
              .fillMaxWidth()
              .height(56.dp)
              .testTag("clean_now_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = EmeraldClean
            )
          ) {
            if (isScanning || isCleaning) {
              CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = DeepNavy,
                strokeWidth = 3.dp
              )
              Spacer(modifier = Modifier.width(12.dp))
              Text(
                text = if (isScanning) AppStrings.getScanningText(language) else AppStrings.getCleaningText(language),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = DeepNavy
              )
            } else {
              Icon(
                imageVector = Icons.Default.CleaningServices,
                contentDescription = null,
                tint = DeepNavy,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = if (cleanerState == CleanerState.SCAN_COMPLETED) {
                  "${AppStrings.getCleanNowBtn(language)} (${AppStrings.formatBytes(stats.junkTotalBytes)})"
                } else {
                  AppStrings.getCleanNowBtn(language)
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = DeepNavy
              )
            }
          }
        }
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Storage & RAM circular gauge
      item {
        Spacer(modifier = Modifier.height(4.dp))
        StorageGauge(
          stats = stats,
          isScanning = isScanning,
          language = language
        )
      }

      // 2. Scan / Clean Progress Indicator if active
      if (isScanning || isCleaning) {
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = statusMessage,
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.SemiBold,
                  color = ElectricCyan,
                  maxLines = 1,
                  modifier = Modifier.weight(1f)
                )
                Text(
                  text = "${(scanProgress * 100).toInt()}%",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = ElectricCyan
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              LinearProgressIndicator(
                progress = { scanProgress },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(8.dp)
                  .clip(RoundedCornerShape(4.dp)),
                color = ElectricCyan,
                trackColor = MaterialTheme.colorScheme.surface
              )
            }
          }
        }
      }

      // 3. Quick Action Row: RAM Booster & Rescan
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // RAM Booster
          OutlinedButton(
            onClick = { viewModel.boostRamOnly() },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("boost_ram_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(
              containerColor = AmberWarning.copy(alpha = 0.1f),
              contentColor = AmberWarning
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning.copy(alpha = 0.4f))
          ) {
            Icon(
              imageVector = Icons.Default.Speed,
              contentDescription = null,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = AppStrings.getBoostRam(language),
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold
            )
          }

          // Scan Trigger
          OutlinedButton(
            onClick = { viewModel.startScan(autoClean = false) },
            enabled = !isScanning && !isCleaning,
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("scan_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(
              containerColor = ElectricCyan.copy(alpha = 0.1f),
              contentColor = ElectricCyan
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.4f))
          ) {
            Icon(
              imageVector = Icons.Default.Search,
              contentDescription = null,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = AppStrings.getScanBtn(language),
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // 4. Tab Selector (Target Apps vs Junk Breakdown vs System Health)
      item {
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          contentColor = ElectricCyan,
          modifier = Modifier.clip(RoundedCornerShape(14.dp))
        ) {
          Tab(
            selected = selectedTab == 0,
            onClick = { viewModel.setSelectedTab(0) },
            text = {
              Text(
                text = AppStrings.getTargetAppsTab(language),
                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                fontSize = 13.sp
              )
            }
          )
          Tab(
            selected = selectedTab == 1,
            onClick = { viewModel.setSelectedTab(1) },
            text = {
              Text(
                text = AppStrings.getJunkCategoriesTab(language),
                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                fontSize = 13.sp
              )
            }
          )
          Tab(
            selected = selectedTab == 2,
            onClick = { viewModel.setSelectedTab(2) },
            text = {
              Text(
                text = AppStrings.getSystemBoostTab(language),
                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                fontSize = 13.sp
              )
            }
          )
        }
      }

      // Tab Content:
      when (selectedTab) {
        0 -> {
          // Tab 0: Target Apps (WhatsApp, Facebook, Messenger, YouTube, Instagram, Google Chrome, Twitter/X, Google)
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (language == AppLanguage.MIZO) {
                  "App bik Cache & Bawlhhlawh tihfaina"
                } else {
                  "App-Specific Cache & Junk Cleaning"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${targetApps.count { it.isInstalled }} installed",
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldClean
              )
            }
          }

          items(targetApps, key = { it.packageName }) { appInfo ->
            AppTargetCard(
              appInfo = appInfo,
              language = language,
              onOpenSettings = { pkg -> viewModel.openAppStorageSettings(pkg) }
            )
          }
        }

        1 -> {
          // Tab 1: Categorized Junk Groups
          item {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (language == AppLanguage.MIZO) "Junk Files & Cache Category" else "Junk Files & Cache Categories",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = AppStrings.formatBytes(junkGroups.filter { it.isSelected }.sumOf { it.totalSizeBytes }),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = ElectricCyan
              )
            }
          }

          items(junkGroups, key = { it.category }) { group ->
            JunkCategoryCard(
              group = group,
              language = language,
              onToggleCategory = { type -> viewModel.toggleCategorySelection(type) },
              onToggleExpand = { type -> viewModel.toggleCategoryExpanded(type) },
              onToggleItem = { type, id -> viewModel.toggleItemSelection(type, id) }
            )
          }
        }

        2 -> {
          // Tab 2: System Health & Performance
          item {
            SystemHealthSection(
              stats = stats,
              language = language,
              onBoost = { viewModel.boostRamOnly() },
              onOpenStorage = { viewModel.openSystemStorageSettings() }
            )
          }
        }
      }

      // Developer Footer Badge
      item {
        Spacer(modifier = Modifier.height(10.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            .clickable { viewModel.setShowDevDialog(true) }
            .padding(14.dp),
          contentAlignment = Alignment.Center
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Code,
              contentDescription = null,
              tint = ElectricCyan,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Developed by Laltlanlawma • Native High Performance Cleaner",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
          }
        }
        Spacer(modifier = Modifier.height(20.dp))
      }
    }
  }
}

@Composable
private fun LanguageChip(
  text: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(14.dp))
      .background(if (isSelected) ElectricCyan else Color.Transparent)
      .clickable { onClick() }
      .padding(horizontal = 10.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      color = if (isSelected) DeepNavy else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    )
  }
}

@Composable
private fun SystemHealthSection(
  stats: com.example.model.DevicePerformanceStats,
  language: AppLanguage,
  onBoost: () -> Unit,
  onOpenStorage: () -> Unit
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Health Score Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
      )
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(EmeraldClean.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.HealthAndSafety,
            contentDescription = null,
            tint = EmeraldClean,
            modifier = Modifier.size(32.dp)
          )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = if (language == AppLanguage.MIZO) "System Health Score" else "System Health Score",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = if (language == AppLanguage.MIZO) "Phone performance a tha thawkhat e" else "System performance is optimal",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
          )
        }

        Text(
          text = "${stats.systemHealthScore}/100",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Black,
          color = EmeraldClean
        )
      }
    }

    // Storage Breakdown Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
      )
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        Text(
          text = if (language == AppLanguage.MIZO) "Storage Kimchang" else "Storage Breakdown",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(12.dp))

        StatRow(
          title = if (language == AppLanguage.MIZO) "Storage Total" else "Total Storage",
          value = AppStrings.formatBytes(stats.storageTotalBytes)
        )
        StatRow(
          title = if (language == AppLanguage.MIZO) "Storage Hman tawh" else "Used Storage",
          value = AppStrings.formatBytes(stats.storageUsedBytes),
          valueColor = AmberWarning
        )
        StatRow(
          title = if (language == AppLanguage.MIZO) "Storage Awl la awm" else "Free Space",
          value = AppStrings.formatBytes(stats.storageFreeBytes),
          valueColor = ElectricCyan
        )
        StatRow(
          title = if (language == AppLanguage.MIZO) "Total RAM" else "Total RAM",
          value = AppStrings.formatBytes(stats.ramTotalBytes)
        )
        StatRow(
          title = if (language == AppLanguage.MIZO) "RAM awl" else "Free RAM",
          value = AppStrings.formatBytes(stats.ramFreeBytes),
          valueColor = EmeraldClean
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = onOpenStorage,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
        ) {
          Icon(
            imageVector = Icons.Default.Storage,
            contentDescription = null,
            tint = DeepNavy,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (language == AppLanguage.MIZO) "Android Storage Settings Hawng Rawh" else "Open Android Storage Settings",
            color = DeepNavy,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}

@Composable
private fun StatRow(
  title: String,
  value: String,
  valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodyMedium,
      fontWeight = FontWeight.Bold,
      color = valueColor
    )
  }
}
