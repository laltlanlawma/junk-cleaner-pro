package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import com.example.util.AppLanguage

@Composable
fun DeveloperInfoDialog(
  language: AppLanguage,
  onDismiss: () -> Unit,
  onOpenStorageSettings: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // App / Dev Avatar with Glowing Gradient
        Box(
          modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(
              Brush.linearGradient(listOf(ElectricCyan, EmeraldClean))
            ),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Speed,
            contentDescription = null,
            tint = DeepNavy,
            modifier = Modifier.size(38.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = "Junk Cleaner Pro",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Black,
          color = MaterialTheme.colorScheme.onSurface
        )

        // Developer Credit Pill (Prominent as requested by user)
        Spacer(modifier = Modifier.height(6.dp))
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(ElectricCyan.copy(alpha = 0.15f))
            .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = null,
              tint = ElectricCyan,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Developer: Laltlanlawma",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              color = ElectricCyan
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = if (language == AppLanguage.MIZO) {
            "He application hi WhatsApp, Facebook, Messenger, YouTube, Instagram, Google Chrome, Twitter/X leh phone chhung bawlhhlawh dang zawng zawng awlsam leh chak taka tihfaina tur leh Phone Storage & RAM chhuah zangkhaina tura duan a ni."
          } else {
            "Native Android application built to effortlessly clean WhatsApp, Facebook, YouTube, Instagram, Chrome, Twitter, and system junk files, freeing up storage and accelerating RAM performance."
          },
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
          lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Features Checklist
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FeatureRow(icon = Icons.Default.Security, text = if (language == AppLanguage.MIZO) "100% On-Device & Safe Clean" else "100% Safe Local Cleaning")
          FeatureRow(icon = Icons.Default.FlashOn, text = if (language == AppLanguage.MIZO) "System-Level RAM & Storage Booster" else "Native RAM & Storage Acceleration")
          FeatureRow(icon = Icons.Default.Apps, text = if (language == AppLanguage.MIZO) "WhatsApp, FB, IG, YT, X, Chrome direct clean" else "Deep App Cache Cleaner")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onOpenStorageSettings,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(text = if (language == AppLanguage.MIZO) "Storage" else "Storage Settings", fontSize = 12.sp)
          }

          Button(
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
          ) {
            Text(
              text = if (language == AppLanguage.MIZO) "Awle / Close" else "Close",
              color = DeepNavy,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }
  }
}

@Composable
private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = EmeraldClean,
      modifier = Modifier.size(16.dp)
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = text,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
      fontWeight = FontWeight.Medium
    )
  }
}
