package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class JunkCategoryType {
  APP_CACHE,
  WHATSAPP_JUNK,
  SOCIAL_MEDIA_CACHE,
  TEMP_FILES,
  OBSOLETE_APKS,
  EMPTY_FOLDERS,
  BIG_FILES
}

data class JunkItem(
  val id: String,
  val title: String,
  val path: String,
  val sizeBytes: Long,
  val category: JunkCategoryType,
  val isSelected: Boolean = true,
  val fileCount: Int = 1,
  val description: String = "",
  val lastModified: Long = System.currentTimeMillis()
)

data class JunkCategoryGroup(
  val category: JunkCategoryType,
  val nameMizo: String,
  val nameEn: String,
  val descriptionMizo: String,
  val descriptionEn: String,
  val items: List<JunkItem>,
  val totalSizeBytes: Long,
  val isSelected: Boolean = true,
  val isExpanded: Boolean = false,
  val accentColor: Color = ElectricCyan
)

data class TargetAppInfo(
  val packageName: String,
  val appName: String,
  val brandColor: Color,
  val isInstalled: Boolean,
  val estimatedCacheBytes: Long,
  val junkFilesCount: Int,
  val specificJunkTypes: List<String>, // e.g. "Voice Notes Cache", "Sent Media", "Web Cache"
  val guideMizo: String,
  val guideEn: String,
  val hasDirectStorageAccess: Boolean = true
)

data class DevicePerformanceStats(
  val storageTotalBytes: Long = 0L,
  val storageUsedBytes: Long = 0L,
  val storageFreeBytes: Long = 0L,
  val ramTotalBytes: Long = 0L,
  val ramUsedBytes: Long = 0L,
  val ramFreeBytes: Long = 0L,
  val junkTotalBytes: Long = 0L,
  val junkItemsCount: Int = 0,
  val isBatterySavingGood: Boolean = true,
  val runningProcessesEstimated: Int = 18,
  val systemHealthScore: Int = 85
)

enum class CleanerState {
  IDLE,
  SCANNING,
  SCAN_COMPLETED,
  CLEANING,
  CLEAN_COMPLETED
}

data class CleanResult(
  val freedBytes: Long,
  val cleanedFilesCount: Int,
  val boostedRamMb: Long,
  val cleanedCategories: List<JunkCategoryType>
)
