package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.service.StorageCleanerService
import com.example.service.SystemInfoHelper
import com.example.util.AppLanguage
import com.example.util.AppStrings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CleanerViewModel(application: Application) : AndroidViewModel(application) {

  private val systemInfoHelper = SystemInfoHelper(application)
  private val cleanerService = StorageCleanerService(application)

  private val _appLanguage = MutableStateFlow(AppLanguage.MIZO)
  val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

  private val _deviceStats = MutableStateFlow(DevicePerformanceStats())
  val deviceStats: StateFlow<DevicePerformanceStats> = _deviceStats.asStateFlow()

  private val _targetApps = MutableStateFlow<List<TargetAppInfo>>(emptyList())
  val targetApps: StateFlow<List<TargetAppInfo>> = _targetApps.asStateFlow()

  private val _junkGroups = MutableStateFlow<List<JunkCategoryGroup>>(emptyList())
  val junkGroups: StateFlow<List<JunkCategoryGroup>> = _junkGroups.asStateFlow()

  private val _cleanerState = MutableStateFlow(CleanerState.IDLE)
  val cleanerState: StateFlow<CleanerState> = _cleanerState.asStateFlow()

  private val _scanProgress = MutableStateFlow(0f)
  val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

  private val _statusMessage = MutableStateFlow("")
  val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

  private val _lastCleanResult = MutableStateFlow<CleanResult?>(null)
  val lastCleanResult: StateFlow<CleanResult?> = _lastCleanResult.asStateFlow()

  private val _selectedTab = MutableStateFlow(0)
  val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

  private val _showDevDialog = MutableStateFlow(false)
  val showDevDialog: StateFlow<Boolean> = _showDevDialog.asStateFlow()

  private val _snackBarMessage = MutableStateFlow<String?>(null)
  val snackBarMessage: StateFlow<String?> = _snackBarMessage.asStateFlow()

  init {
    loadInitialStats()
    startScan(autoClean = false)
  }

  fun setLanguage(language: AppLanguage) {
    _appLanguage.value = language
  }

  fun setSelectedTab(index: Int) {
    _selectedTab.value = index
  }

  fun setShowDevDialog(show: Boolean) {
    _showDevDialog.value = show
  }

  fun clearSnackbar() {
    _snackBarMessage.value = null
  }

  fun loadInitialStats() {
    val stats = systemInfoHelper.getDeviceStats()
    _deviceStats.value = stats
    _targetApps.value = systemInfoHelper.getTargetApps()
  }

  fun startScan(autoClean: Boolean = false) {
    viewModelScope.launch {
      _cleanerState.value = CleanerState.SCANNING
      _scanProgress.value = 0f
      _statusMessage.value = if (_appLanguage.value == AppLanguage.MIZO) {
        "Storage leh Cache te kan lo enfiah mek..."
      } else {
        "Scanning storage, app cache and junk files..."
      }

      val scannedGroups = cleanerService.scanStorage { progress, status ->
        _scanProgress.value = progress
        _statusMessage.value = status
      }

      _junkGroups.value = scannedGroups
      val totalJunkBytes = scannedGroups.sumOf { it.totalSizeBytes }
      val totalJunkCount = scannedGroups.sumOf { it.items.sumOf { item -> item.fileCount } }

      _deviceStats.value = systemInfoHelper.getDeviceStats(totalJunkBytes, totalJunkCount)
      _targetApps.value = systemInfoHelper.getTargetApps()
      _cleanerState.value = CleanerState.SCAN_COMPLETED

      if (autoClean) {
        cleanSelectedJunk()
      }
    }
  }

  fun cleanSelectedJunk() {
    viewModelScope.launch {
      _cleanerState.value = CleanerState.CLEANING
      _scanProgress.value = 0f
      _statusMessage.value = if (_appLanguage.value == AppLanguage.MIZO) {
        "Bawlhhlawh thian fai mek..."
      } else {
        "Cleaning selected junk..."
      }

      val result = cleanerService.cleanJunk(_junkGroups.value) { progress, status ->
        _scanProgress.value = progress
        _statusMessage.value = status
      }

      _lastCleanResult.value = result
      _cleanerState.value = CleanerState.CLEAN_COMPLETED

      // Refresh post-clean stats
      val updatedStats = systemInfoHelper.getDeviceStats(
        junkFoundBytes = 0L,
        junkCount = 0
      )
      _deviceStats.value = updatedStats.copy(
        storageUsedBytes = (updatedStats.storageUsedBytes - result.freedBytes).coerceAtLeast(1024L * 1024L * 1024L),
        ramUsedBytes = (updatedStats.ramUsedBytes - (result.boostedRamMb * 1024L * 1024L)).coerceAtLeast(1024L * 1024L * 500L)
      )

      // Clear cleaned groups
      _junkGroups.update { groups ->
        groups.map { group ->
          if (group.isSelected) {
            group.copy(items = emptyList(), totalSizeBytes = 0L)
          } else group
        }
      }

      val freedStr = AppStrings.formatBytes(result.freedBytes)
      _snackBarMessage.value = if (_appLanguage.value == AppLanguage.MIZO) {
        "Storage ${freedStr} tihfai a ni a, RAM ${result.boostedRamMb}MB tihchak a ni e!"
      } else {
        "Freed ${freedStr} of storage and boosted ${result.boostedRamMb}MB of RAM!"
      }
    }
  }

  fun boostRamOnly() {
    viewModelScope.launch {
      _statusMessage.value = if (_appLanguage.value == AppLanguage.MIZO) "RAM tichak mek..." else "Boosting RAM..."
      val boostedMb = cleanerService.boostMemory()
      val current = _deviceStats.value
      _deviceStats.value = current.copy(
        ramUsedBytes = (current.ramUsedBytes - (boostedMb * 1024L * 1024L)).coerceAtLeast(1024L * 1024L * 400L),
        ramFreeBytes = current.ramFreeBytes + (boostedMb * 1024L * 1024L)
      )
      _snackBarMessage.value = AppStrings.getRamBoostedMessage(_appLanguage.value, boostedMb)
    }
  }

  fun toggleCategorySelection(categoryType: JunkCategoryType) {
    _junkGroups.update { list ->
      list.map { group ->
        if (group.category == categoryType) {
          val newSelected = !group.isSelected
          group.copy(
            isSelected = newSelected,
            items = group.items.map { it.copy(isSelected = newSelected) }
          )
        } else group
      }
    }
  }

  fun toggleCategoryExpanded(categoryType: JunkCategoryType) {
    _junkGroups.update { list ->
      list.map { group ->
        if (group.category == categoryType) {
          group.copy(isExpanded = !group.isExpanded)
        } else group
      }
    }
  }

  fun toggleItemSelection(categoryType: JunkCategoryType, itemId: String) {
    _junkGroups.update { list ->
      list.map { group ->
        if (group.category == categoryType) {
          val updatedItems = group.items.map { item ->
            if (item.id == itemId) item.copy(isSelected = !item.isSelected) else item
          }
          val anySelected = updatedItems.any { it.isSelected }
          val newTotal = updatedItems.filter { it.isSelected }.sumOf { it.sizeBytes }
          group.copy(items = updatedItems, isSelected = anySelected, totalSizeBytes = newTotal)
        } else group
      }
    }
  }

  fun openAppStorageSettings(packageName: String) {
    systemInfoHelper.openAppStorageSettings(packageName)
  }

  fun openSystemStorageSettings() {
    systemInfoHelper.openStorageSettings()
  }
}
